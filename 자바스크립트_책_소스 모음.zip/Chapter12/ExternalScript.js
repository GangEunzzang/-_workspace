function externalFileFunction() { }
var externalFileVariable = 'Hello World..!';
alert('Import External Script Complete');